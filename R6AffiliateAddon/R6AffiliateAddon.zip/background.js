var userubiID;


const DISCORD_URI_ENDPOINT = 'https://discord.com/api/oauth2/authorize';
const CLIENT_ID = encodeURIComponent('982396763019280384');
const RESPONSE_TYPE = encodeURIComponent('token');
const REDIRECT_URI = encodeURIComponent('https://iodmcahcbobdhpggnobnnnpinpkcgbkm.chromiumapp.org/');
const SCOPE = encodeURIComponent('identify email');
const STATE = encodeURIComponent('meet' + Math.random().toString(36).substring(2, 15));

let user_signed_in = false; 

function create_auth_endpoint() {
    let nonce = encodeURIComponent(Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15));

    let endpoint_url =
        `${DISCORD_URI_ENDPOINT}
?client_id=${CLIENT_ID}
&redirect_uri=${REDIRECT_URI}
&response_type=${RESPONSE_TYPE}
&scope=${SCOPE}
&nonce=${nonce}`;

    return endpoint_url;
}


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.message === 'login') {
        chrome.identity.launchWebAuthFlow({
            url: create_auth_endpoint(),
            interactive: true
        }, function (redirect_uri) {
            if (chrome.runtime.lastError || redirect_uri.includes('access_denied')) {
                console.log("Konnte nicht authentifizieren.");
                sendResponse('fail');
            } else {
                user_signed_in = true;
               
                const fragment = new URLSearchParams(redirect_uri.slice(1))
		        const [accessToken, tokenType] = [fragment.get('access_token'), fragment.get('token_type')];
                fetch('https://discord.com/api/users/@me', {
			headers: {
				authorization: `${'Bearer'} ${accessToken}`,
			},
		}).then(result => result.json())
        .then(response => {
            const { id } = response;
            var userdc = id;
            var userubi;
            chrome.storage.local.get(['ubiID'], function(result) {
                userubi = result.ubiID
            
                fetch(`https://rainbowsixde.000webhostapp.com//insert.php?ubiID=${userubi}&dcID=${userdc}`)
                chrome.action.setPopup({popup: "popup-sign-out.html"});
                chrome.storage.sync.set({dpopup: "popup-sign-out.html"}, function() {
                  });
                chrome.runtime.setUninstallURL(`https://rainbowsixde.000webhostapp.com//config.php?ubiID=${userubi}`)
              });

           
            sendResponse('success');
            
        })
        .catch(console.error);
            }
        });

        return true;
    } else if (request.message === 'logout') {
        user_signed_in = false;

        sendResponse('success');
    } else if (request.message === 'userid') {
        

        sendResponse(userdc);
    } else if(request.message === 'content') {

        chrome.storage.local.set({ubiID: request.ubiID});
        chrome.action.setPopup({popup: "./popup-sign-in.html"});

    }
});

chrome.runtime.onStartup.addListener(function() {
    chrome.storage.sync.get(['dpopup'], function(result) {
        if(result.dpopup == "popup-sign-out.html") {
            chrome.action.setPopup({popup: "popup-sign-out.html"});
        }

      });
  })

