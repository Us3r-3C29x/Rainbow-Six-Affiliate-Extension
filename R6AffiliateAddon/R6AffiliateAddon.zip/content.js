// @name          Rainbow Six | DE | Ranked
// @namespace     
// @description   Mit dieser Erweiterung wird automatisch dein Rang auf dem Rainbow Six | DE angezeigt! Außerdem unterstützt du den Server kostenfrei.
// @include       *
// @run-at        document-end
// @version       2.0

// Defining the Affiliate ID
var affID = 'r6de-21';
// Get the Product ASIN
function getASIN(href) {
  var asinMatch;
  if (!asinMatch) {asinMatch = href.match(/\/exec\/obidos\/ASIN\/(\w{10})/i); }
  if (!asinMatch) { asinMatch = href.match(/\/gp\/product\/(\w{10})/i); }
  if (!asinMatch) { asinMatch = href.match(/\/exec\/obidos\/tg\/detail\/\-\/(\w{10})/i); }
  if (!asinMatch) { asinMatch = href.match(/\/dp\/(\w{10})/i); }
  if (!asinMatch) { asinMatch = href.match(/\/exec\/o\/ASIN\/(\w{10})/i); }
  if (!asinMatch) { return null; }
  return asinMatch[1];
}




// Get The Domain
function getDomain() {
  if (document.location.hostname.substr(0,4) == 'www.') {
    return document.location.hostname.substr(4) ;
  }
  return document.location.hostname ;
}


 function getubiID(){
  var ubiID;
  
  for (const a of document.querySelectorAll("img")) {
    if (a.getAttribute('src').includes("https://ubisoft-avatars.akamaized.net/")) {
      ubiID = a.getAttribute('src')
    }
  }

  if(ubiID == null || ubiID == undefined) {
    setTimeout(getubiID,250);
  } else {
    ubiID = ubiID.split('/')
    ubiID = ubiID[3]
if(ubiID) {
    chrome.runtime.sendMessage({
      message: 'content',
      ubiID: `${ubiID}`
    });
    setTimeout(() => {
      window.alert(`Dein Ubisoft ist nun verbunden!\nBitte verbinde als nächstes dein Discord Konto, um den Vorgang abzuschließen! Klicke dafür nochmal oben rechts auf die Erweiterung.\nDu kannst diesen Tab nun schließen.`)
    }, 500);
  }
    
    
    return;
  }
  }


// The Main Function
(function() {
if(window.location.host == "account.ubisoft.com") {
   getubiID();
}


  // Scope
  var currentDomain = getDomain();
  var linkDomain = (currentDomain.match(/amazon\./i) ? currentDomain : "amazon.com");

  // Correct the URL if wrong
if (window.location.href.includes(affID) == false  && ((window.location.href.includes("/obidos/") || window.location.href.includes("/o/") || window.location.href.includes("/dp/") || window.location.href.includes("/product/")) == true)) { 
  var curAsin = getASIN(window.location.href)
  window.location = ("http://"+linkDomain+"/o/ASIN/" + curAsin + "/ref=nosim/"+affID);
}

  // Get All Of Our Links And Loop
  var allLinks = document.getElementsByTagName("a");
  for (var i = 0; i < allLinks.length; i++) {
    var href = allLinks[i].href;
    if (href.match(/amazon\./i)) {
     var asin = getASIN(href);
      if (asin != null) {    allLinks[i].setAttribute("href", "http://"+linkDomain+"/o/ASIN/" + asin + "/ref=nosim/"+affID);}
    }
  }
 
})();


