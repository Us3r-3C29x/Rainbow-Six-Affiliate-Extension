const button = document.querySelector('button');
// import { userubi } from './content.js';


function openInNewTab(url) {
        const win = window.open(url, '_blank');
        win.focus();
      }

button.addEventListener('mouseover', () => {
    button.style.backgroundColor = 'black';
    button.style.color = 'white';
    button.style.transform = 'scale(1.1)';
});

button.addEventListener('mouseleave', () => {
    button.style.backgroundColor = '#30c41a';
    button.style.color = 'black';
    button.style.transform = 'scale(1)';
});

button.addEventListener('click', () => {

    openInNewTab('https://account.ubisoft.com/de-DE')

});
