const button = document.querySelector('button');

button.addEventListener('mouseover', () => {
    button.style.backgroundColor = 'black';
    button.style.color = 'white';
    button.style.transform = 'scale(1.1)';
});

button.addEventListener('mouseleave', () => {
    button.style.backgroundColor = '#30c41a';
    button.style.color = 'black';
    button.style.transform = 'scale(1)';
});

button.addEventListener('click', () => {
    chrome.runtime.sendMessage({ message: 'login' }, function (response) {
        if (response == 'success') { 
            window.location.replace("popup-sign-out.html");
            window.alert("Dein Ubisoft Konto ist nun mit deinem Discord Konto erfolgreich verknüpft!")
        } else {
            window.alert("Kein Discord Konto verknüpft. Bitte versuche es noch einmal!")
        }
    });
});


