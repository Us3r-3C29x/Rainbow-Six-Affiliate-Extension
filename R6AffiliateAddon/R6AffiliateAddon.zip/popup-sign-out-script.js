const button = document.querySelector('button');

button.addEventListener('mouseover', () => {
    button.style.backgroundColor = 'black';
    button.style.color = 'white';
    button.style.transform = 'scale(1.1)';

    document.querySelector('div').style.backgroundColor = '#36393E';
});

button.addEventListener('mouseleave', () => {
    button.style.backgroundColor = '#e83d23';
    button.style.color = 'black';
    button.style.transform = 'scale(1)';

    document.querySelector('div').style.backgroundColor = '#36393E';
});

button.addEventListener('click', () => {
    chrome.runtime.sendMessage({ message: 'logout' }, function (response) {
        if (response === 'success') {
            chrome.storage.sync.set({dpopup: null}, function() {
            });
             window.location.replace("popup-sign-ubisoft.html");
             chrome.action.setPopup({popup: "popup-sign-ubisoft.html"});
        }
    });
});

